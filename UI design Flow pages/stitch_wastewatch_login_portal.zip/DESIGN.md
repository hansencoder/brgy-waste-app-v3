---
name: Ethereal Sustainability
colors:
  surface: '#f7f9fb'
  surface-dim: '#d8dadc'
  surface-bright: '#f7f9fb'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f4f6'
  surface-container: '#eceef0'
  surface-container-high: '#e6e8ea'
  surface-container-highest: '#e0e3e5'
  on-surface: '#191c1e'
  on-surface-variant: '#45464d'
  inverse-surface: '#2d3133'
  inverse-on-surface: '#eff1f3'
  outline: '#76777d'
  outline-variant: '#c6c6cd'
  surface-tint: '#565e74'
  primary: '#000000'
  on-primary: '#ffffff'
  primary-container: '#131b2e'
  on-primary-container: '#7c839b'
  inverse-primary: '#bec6e0'
  secondary: '#006c49'
  on-secondary: '#ffffff'
  secondary-container: '#6cf8bb'
  on-secondary-container: '#00714d'
  tertiary: '#000000'
  on-tertiary: '#ffffff'
  tertiary-container: '#002117'
  on-tertiary-container: '#528f79'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dae2fd'
  primary-fixed-dim: '#bec6e0'
  on-primary-fixed: '#131b2e'
  on-primary-fixed-variant: '#3f465c'
  secondary-fixed: '#6ffbbe'
  secondary-fixed-dim: '#4edea3'
  on-secondary-fixed: '#002113'
  on-secondary-fixed-variant: '#005236'
  tertiary-fixed: '#b0f0d6'
  tertiary-fixed-dim: '#95d3ba'
  on-tertiary-fixed: '#002117'
  on-tertiary-fixed-variant: '#0b513d'
  background: '#f7f9fb'
  on-background: '#191c1e'
  surface-variant: '#e0e3e5'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  display-md:
    fontFamily: Inter
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
  headline-sm:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
  label-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.05em
  display-md-mobile:
    fontFamily: Inter
    fontSize: 30px
    fontWeight: '700'
    lineHeight: 38px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 8px
  xs: 4px
  sm: 12px
  md: 24px
  lg: 48px
  xl: 80px
  gutter: 24px
  margin: 64px
---

## Brand & Style

This design system embodies a **Modern Corporate** aesthetic with a strong emphasis on precision, environmental stewardship, and technological sophistication. It balances institutional reliability with a high-polish, contemporary feel.

The brand personality is authoritative yet accessible, targeting municipal stakeholders and modern community residents. It utilizes a split-screen philosophy that contrasts deep, immersive environments with clean, functional interaction surfaces. Visual depth is achieved through subtle tonal layering and soft, diffused shadows rather than heavy decorative elements.

## Colors

The palette is built on a foundation of "Deep Midnight" (Navy) and "Emerald Forest" (Green). 

- **Primary:** A deep navy used for critical actions and high-contrast text.
- **Secondary:** A vibrant emerald green used for brand accents, status indicators, and success states.
- **Tertiary:** A very dark forest green used for immersive backgrounds and brand-heavy hero sections.
- **Surface:** A palette of cool grays and off-whites provides a clean canvas for information density.

For dark-themed sections (like hero areas), use the tertiary green with low-opacity white overlays for secondary text to maintain legibility while preserving the environmental mood.

## Typography

The system relies exclusively on **Inter** to deliver a neutral, systematic, and highly legible experience. 

- **Headlines:** Utilize tighter letter-spacing and bold weights to command attention.
- **Body:** Standardized on 16px for optimal readability across all municipal data.
- **Labels:** Use medium weights (500) to distinguish metadata from body content.
- **Contrast:** On dark backgrounds, use "White" for primary text and "White/60%" for secondary descriptors.

## Layout & Spacing

The layout follows a **Fluid Grid** model with generous horizontal margins to ensure content remains centered and readable.

- **Split Layouts:** For authentication and marketing, use a 50/50 split on desktop. On mobile, the immersive dark section collapses to a top banner (25% height) or is removed entirely.
- **Rhythm:** An 8px base grid drives all spacing. Use `48px` (lg) or `80px` (xl) for vertical section breathing room to maintain the "high-polish" aesthetic.
- **Alignment:** Consistent left-alignment is preferred for all forms and data entries to ensure a clear scanning path.

## Elevation & Depth

This system uses **Tonal Layers** combined with **Ambient Shadows** to create a sense of organized hierarchy.

- **Low Elevation:** Input fields and secondary buttons use a subtle 1px border with a very soft, low-opacity shadow (4% opacity) to lift them slightly from the page.
- **High Elevation:** Primary containers or "active" cards use a more pronounced, diffused shadow (12% opacity, 16px blur) to indicate focus.
- **Hero Depth:** Within dark sections, use horizontal rules with 10% white opacity to separate content without adding visual noise.

## Shapes

The design uses a **Rounded** shape language to soften the corporate feel and make the interface feel more modern and approachable.

- **Standard Radius:** 8px (`0.5rem`) for inputs, buttons, and small containers.
- **Large Radius:** 16px (`1rem`) for large cards and feature blocks.
- **Pill Shapes:** Used exclusively for tags, badges (e.g., status indicators), and segmented controls to provide a distinct visual contrast from functional inputs.

## Components

### Buttons
- **Primary:** Pill-shaped or heavily rounded (8px+), navy background with white text. Includes a right-pointing arrow icon for directional actions.
- **Segmented Control:** A light gray track with a white, elevated pill for the active state.

### Input Fields
- **Text Inputs:** White background with a subtle gray border. Focus state should use a 2px green border or a subtle outer glow.
- **Labels:** Positioned strictly above the field in a 14px medium weight.

### Chips & Badges
- **Status Chips:** Pill-shaped with a low-opacity green background and dark green text. Often paired with a small leading dot.

### Cards & Containers
- **Information Cards:** Transparent backgrounds with white text (on dark) or white backgrounds with subtle shadows (on light). 
- **Separators:** Use 1px borders with 10-15% opacity of the contrasting color.

### Interactive Elements
- **Links:** Secondary green text, medium weight, no underline unless hovered.
- **Checkboxes:** Rounded squares (4px radius) to match the general shape language.